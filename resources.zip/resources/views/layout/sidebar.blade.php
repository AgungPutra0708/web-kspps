@if (Route::currentRouteName() != 'login')
    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion d-none d-lg-block" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0" />

        <!-- Nav Item - Dashboard -->
        <li class="nav-item active">
            <a class="nav-link" href="{{ route('home') }}">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider" />

        <!-- Heading -->
        <div class="sidebar-heading">Keanggotaan</div>

        <!-- Nav Item - Anggota Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('anggota') }}">
                <i class="fas fa-user-plus"></i>
                <span>Anggota</span></a>
        </li>

        <!-- Nav Item - Management User Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('management_user') }}">
                <i class="fas fa-user"></i>
                <span>Managemen User Anggota</span></a>
        </li>

        <!-- Nav Item - Produk Simpanan Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('simpanan') }}">
                <i class="fas fa-wallet"></i>
                <span>Produk Simpanan</span></a>
        </li>

        <!-- Nav Item - Input Data Simpanan Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('input_simpanan') }}">
                <i class="fas fa-cash-register"></i>
                <span>Input Data Simpanan</span></a>
        </li>

        <!-- Nav Item - Produk Pembiayaan Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('pembiayaan') }}">
                <i class="fa fa-money-bill"></i>
                <span>Produk Pembiayaan</span></a>
        </li>

        <!-- Nav Item - Input Data Pembiayaan Menu -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('input_pembiayaan') }}">
                <i class="fas fa-handshake"></i>
                <span>Input Data Pembiayaan</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider" />

        <!-- Heading -->
        <div class="sidebar-heading">Transaksi Simpanan</div>

        <!-- Nav Item - Setor Kolektif -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('input_simpanan_kolektif') }}">
                <i class="fas fa-plus-square"></i>
                <span>Setor Kolektif</span>
            </a>
        </li>

        <!-- Nav Item - Penarikan Kolektif -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('penarikan_simpanan_kolektif') }}">
                <i class="fas fa-minus-square"></i>
                <span>Penarikan Kolektif</span>
            </a>
        </li>

        <!-- Nav Item - Pindah Buku -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('home') }}">
                <i class="fas fa-exchange-alt"></i>
                <span>Pindah Buku</span>
            </a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider" />

        <!-- Heading -->
        <div class="sidebar-heading">Transaksi Pembiayaan</div>

        <!-- Nav Item - Bayar Angsuran Kolektif -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('input_pembiayaan_kolektif') }}">
                <i class="fas fa-receipt"></i>
                <span>Bayar Angsuran Kolektif</span>
            </a>
        </li>

        <!-- Nav Item - Cek -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('home') }}">
                <i class="fas fa-tasks"></i>
                <span>Cek</span>
            </a>
        </li>
    </ul>
    <!-- End of Sidebar -->
@endif
